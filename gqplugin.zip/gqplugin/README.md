# woocommerce variable stock management
This is set out to solve the problem of dealing with woocommerce's variable products only ever deducting one from the total product stock. 
the use Case I had for it was: Client want's to seel packs of cigars 3/5/10 and wants erach variation to deduct from the main product total. 
Simple plugin to manage variable product stock, Update product quantities dynamically, using woocommerce. 
Basically this question http://wordpress.stackexchange.com/questions/72662/woocommerce-fixed-quantity-of-a-product. 
If a product variation needs to update the total stock quantity say you sell packs of nails or packets of cigars and you want…

<h3>Addiditionals</h3>
This also has a bigcommerce category importer to woocommerce. 
can be found here includes/class-import-categories.php you'll need to change line 202 and put your old sites url in there if you want images to be pulled from the descriptions... 
 